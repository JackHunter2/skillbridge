create definer = abdul@`%` view v_user_progress as
select `u`.`user_id`                      AS `user_id`,
       `u`.`full_name`                    AS `full_name`,
       `tr`.`role_name`                   AS `target_role`,
       count(distinct `p`.`portfolio_id`) AS `total_portfolio_versions`,
       min(`r`.`overall_score`)           AS `first_score`,
       max(`r`.`overall_score`)           AS `best_score`,
       (select `r2`.`overall_score`
        from (`upskilling_platform`.`ai_reviews` `r2` join `upskilling_platform`.`portfolios` `p2`
              on ((`p2`.`portfolio_id` = `r2`.`portfolio_id`)))
        where ((`p2`.`user_id` = `u`.`user_id`) and (`r2`.`status` = 'done'))
        order by `r2`.`created_at` desc
        limit 1)                          AS `latest_score`
from (((`upskilling_platform`.`users` `u` left join `upskilling_platform`.`target_roles` `tr`
        on ((`tr`.`role_id` = `u`.`target_role_id`))) left join `upskilling_platform`.`portfolios` `p`
       on ((`p`.`user_id` = `u`.`user_id`))) left join `upskilling_platform`.`ai_reviews` `r`
      on (((`r`.`portfolio_id` = `p`.`portfolio_id`) and (`r`.`status` = 'done'))))
where (`u`.`user_type` in ('fresh_graduate', 'anak_magang'))
group by `u`.`user_id`, `u`.`full_name`, `tr`.`role_name`;

