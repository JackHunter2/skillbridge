create
    definer = abdul@`%` procedure sp_hapus_pengguna(IN p_email varchar(150))
BEGIN
    DECLARE v_id BIGINT UNSIGNED;
    SELECT user_id INTO v_id FROM users WHERE email = p_email;

    IF v_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Pengguna tidak ditemukan';
    END IF;

    DELETE FROM users WHERE user_id = v_id;
    SELECT CONCAT('Akun ', p_email, ' beserta seluruh datanya telah dihapus') AS hasil;
END;

