create definer = abdul@`%` event ev_bersihkan_harian on schedule
    every '1' DAY
        starts '2026-10-24 02:00:00'
    enable
    do
    CALL sp_bersihkan_data();

