create
    definer = abdul@`%` procedure sp_ringkasan_sistem()
BEGIN
    SELECT
        (SELECT COUNT(*) FROM users WHERE user_type IN ('fresh_graduate','anak_magang')) AS total_pengguna,
        (SELECT COUNT(*) FROM portfolios)                                               AS total_portofolio,
        (SELECT COUNT(*) FROM ai_reviews WHERE status = 'done')                         AS reviu_selesai,
        (SELECT COUNT(*) FROM ai_reviews WHERE status = 'failed')                       AS reviu_gagal,
        (SELECT ROUND(AVG(overall_score), 1) FROM ai_reviews WHERE status = 'done')    AS rata_rata_skor,
        (SELECT COUNT(*) FROM user_feedback)                                            AS total_feedback,
        (SELECT ROUND(AVG(ai_accuracy), 1) FROM user_feedback)                          AS rata_rata_akurasi_ai;
END;

