create
    definer = abdul@`%` procedure sp_bersihkan_data()
BEGIN
    DECLARE v_hari  INT DEFAULT 180;
    DECLARE v_reset INT DEFAULT 0;
    DECLARE v_macet INT DEFAULT 0;
    DECLARE v_gagal INT DEFAULT 0;
    DECLARE v_teks  INT DEFAULT 0;

    DELETE FROM password_resets WHERE expires_at < NOW();
    SET v_reset = ROW_COUNT();

    UPDATE ai_reviews
    SET status = 'failed', summary = 'Reviu terhenti, silakan ulangi.'
    WHERE status = 'processing' AND created_at < (NOW() - INTERVAL 10 MINUTE);
    SET v_macet = ROW_COUNT();

    DELETE FROM ai_reviews
    WHERE status = 'failed' AND created_at < (NOW() - INTERVAL 7 DAY);
    SET v_gagal = ROW_COUNT();

    UPDATE portfolios p
    SET p.extracted_text = NULL, p.text_purged_at = NOW()
    WHERE p.extracted_text IS NOT NULL
      AND GREATEST(
                  p.uploaded_at,
                  COALESCE((SELECT MAX(r.created_at) FROM ai_reviews r WHERE r.portfolio_id = p.portfolio_id), p.uploaded_at)
          ) < (NOW() - INTERVAL v_hari DAY);
    SET v_teks = ROW_COUNT();

    SELECT v_reset AS token_reset_dihapus,
           v_macet AS reviu_macet_ditandai,
           v_gagal AS reviu_gagal_dihapus,
           v_teks  AS teks_portofolio_dihapus;
END;

